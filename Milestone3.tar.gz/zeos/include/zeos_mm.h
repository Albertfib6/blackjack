#ifndef zeos_mm_h
#define zeos_mm_h

void monoprocess_init_addr_space() ;

#endif /*zeos_mm_h*/
